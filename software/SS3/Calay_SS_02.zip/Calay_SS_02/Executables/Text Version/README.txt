This bundle also contains the R and Excel readers that read, tabulate and plot the various results.
See the manual for useage.